import io
import requests
import zipfile

import pandas as pd


INPUT_FILE = "genehome PC-IM history.csv"
OUT_FOLD = "interactions_files"
TO_KEEP = ".interactions"
BASE_QUERY = "https://gene.disi.unitn.it/test/gene_result-z.php?id="


exp_df = pd.read_csv(INPUT_FILE)
query_ids = (exp_df["pcim_id"].astype(str) + "_" + exp_df["org"]).tolist()

for q_id in query_ids:
    
    zip_bytes = requests.get(BASE_QUERY + q_id).content
    zf = zipfile.ZipFile(io.BytesIO(zip_bytes), "r")
    zf.extract(q_id + TO_KEEP, OUT_FOLD)
