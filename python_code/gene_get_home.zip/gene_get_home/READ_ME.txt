-------------------------------------------------------------
----------------------- GENE GET HOME -----------------------
-------------------------------------------------------------
Automated retrieval of expansions from the gene@home project

HOW TO USE:
- Download Pandas if not installed already 
  > pip install pandas
- Go at https://gene.disi.unitn.it/test/gene_history-z.php
- Put in the "LGN name" field a string that matches all the 
  expansions you want to download (for instance "snorna_ENSG"
  to match all "snorna_ENSGXXXXXXXXXXX")
- Press "SEARCH"
- In the top-left corner press "CSV"
- A file named "genehome PC-IM history.csv" should be auto-
  matically downloaded. DO NOT rename it.
- Drag the file in the same folder as the script
- Double click the script 
- A folder should appear containing all ".interactions" files 
  you are interested in. 

PARAMETERS:
Manually change them directly in the Python script, they are
the all caps variables at the beginning of the script. I 
cannot be bothered to add the command line thing. 
- INPUT_FILE: name of the .csv file from gene@home
- OUT_FOLD: name of the output folder
- TO_KEEP: which one of the files to keep, since they are 
    basically the same (".expansion" or ".interactions")
- BASE_QUERY: first part of the query. Should be stable